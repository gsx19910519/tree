
AtlasOptions = {
	["AtlasLocked"] = false,
	["AtlasClamped"] = true,
	["AtlasRightClick"] = false,
	["AtlasButtonPosition"] = 181,
	["AtlasAcronyms"] = true,
	["AtlasType"] = 2,
	["AtlasButtonShown"] = true,
	["AtlasVersion"] = "1.0(1.13.0)",
	["AtlasAlpha"] = 1,
	["AtlasButtonRadius"] = 78,
	["AtlasZone"] = 1,
	["AtlasAutoSelect"] = true,
	["AtlasScale"] = 1,
	["AtlasSortBy"] = 1,
}
