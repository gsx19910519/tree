
EavesDropStatsDB = {
	["profileKeys"] = {
		["Mavis - 灰烬使者"] = "Mavis - 灰烬使者",
	},
	["profiles"] = {
		["Mavis - 灰烬使者"] = {
			{
				["heal"] = {
					["生命通道"] = {
						[-2] = {
							["time"] = "|cffffffff09/10/19 01:29:58|r\n|Hunit:Pet-0-4517-0-453-416-010004A985:沃尔提普|h沃尔提普|h因|Hunit:Player-4772-00672F51:Mavis|hMavis的|h|Hspell:0:0:SPELL_PERIODIC_HEAL|h|cffffffff生命通道|r|h获得了|cffffffff0|r点生命值。（43 过量治疗）",
							["amount"] = 43,
						},
						[2] = {
						},
					},
					["急救"] = {
						[-2] = {
							["time"] = "|cffffffff09/10/19 01:38:54|r\n|Hunit:Player-4772-00672F51:Mavis|hMavis|h因|Hunit:Player-4772-00672F51:Mavis|hMavis的|h|Hspell:0:0:SPELL_PERIODIC_HEAL|h|cffffffff急救|r|h获得了|cffffffff43|r点生命值。",
							["amount"] = 43,
						},
						[2] = {
						},
					},
					["吸取生命"] = {
						[-2] = {
							["time"] = "|cffffffff09/10/19 01:27:40|r\n|Hunit:Player-4772-00672F51:Mavis|hMavis的|h|Hspell:0:0:SPELL_HEAL|h|cffffffff吸取生命|r|h为|Hunit:Player-4772-00672F51:Mavis|hMavis|h恢复了|cffffffff18|r点生命值。",
							["amount"] = 18,
						},
						[2] = {
						},
					},
				},
				["hit"] = {
					["吸取生命"] = {
						[-2] = {
							["time"] = "|cffffffff09/10/19 01:27:40|r\n|Hunit:Creature-0-4517-0-453-412-000077302B:缝合怪|h缝合怪|h因|Hunit:Player-4772-00672F51:Mavis|hMavis的|h|Hspell:0:0:SPELL_PERIODIC_DAMAGE|h|cffffffff吸取生命|r|h受到了|cffffffff18|r |cffffffff暗影|r伤害。",
							["amount"] = 18,
						},
						[2] = {
						},
					},
					["腐蚀术"] = {
						[-2] = {
							["time"] = "|cffffffff09/10/19 01:27:40|r\n|Hunit:Creature-0-4517-0-453-412-000077302B:缝合怪|h缝合怪|h因|Hunit:Player-4772-00672F51:Mavis|hMavis的|h|Hspell:0:0:SPELL_PERIODIC_DAMAGE|h|cffffffff腐蚀术|r|h受到了|cffffffff27|r |cffffffff暗影|r伤害。（9 抵抗）",
							["amount"] = 27,
						},
						[2] = {
						},
					},
					["痛苦诅咒"] = {
						[-2] = {
							["time"] = "|cffffffff09/10/19 04:17:20|r\n|Hunit:Creature-0-4517-0-453-412-0000775602:缝合怪|h缝合怪|h因|Hunit:Player-4772-00672F51:Mavis|hMavis的|h|Hspell:0:0:SPELL_PERIODIC_DAMAGE|h|cffffffff痛苦诅咒|r|h受到了|cffffffff10|r |cffffffff暗影|r伤害。（30 抵抗）",
							["amount"] = 10,
						},
						[2] = {
						},
					},
				},
			}, -- [1]
			[-1] = {
				["hit"] = {
					["自然"] = {
						[-2] = {
							["time"] = "|cffffffff09/10/19 01:27:21|r\n|Hunit:Creature-0-4517-0-453-412-000077302B:缝合怪|h缝合怪的|h|Hspell:0:0:SPELL_DAMAGE|h|cffff1313腐蚀光环|r|h命中|Hunit:Player-4772-00672F51:Mavis|hMavis|h造成|cffff131339|r |cffff1313自然|r伤害。",
							["amount"] = 39,
						},
						[2] = {
						},
					},
				},
			},
		},
	},
}
