
PA_AO_DB = {
	["version"] = 1,
	["cvars"] = {
		["chatClassColorOverride"] = "1",
		["cameraDistanceMaxZoomFactor"] = 4,
		["ffxGlow"] = "1",
		["rawMouseAccelerationEnable"] = "1",
		["ShowClassColorInFriendlyNameplate"] = "0",
		["nameplateMaxDistance"] = 80,
		["rawMouseEnable"] = "0",
		["scriptErrors"] = "0",
	},
}
