
ElvDB = {
	["profileKeys"] = {
		["Mavis - 灰烬使者"] = "Mavis - 灰烬使者",
	},
	["gold"] = {
		["灰烬使者"] = {
			["Mavis"] = 94426,
		},
	},
	["class"] = {
		["灰烬使者"] = {
			["Mavis"] = "WARLOCK",
		},
	},
	["global"] = {
		["general"] = {
			["AceGUI"] = {
				["height"] = 644.82,
				["width"] = 879.51,
			},
			["smallerWorldMapScale"] = 0.79,
			["UIScale"] = 0.82,
		},
	},
	["profiles"] = {
		["Minimalistic"] = {
			["currentTutorial"] = 2,
			["general"] = {
				["font"] = "Expressway",
				["bottomPanel"] = false,
				["backdropfadecolor"] = {
					["a"] = 0.80000001192093,
					["b"] = 0.058823529411765,
					["g"] = 0.058823529411765,
					["r"] = 0.058823529411765,
				},
				["reputation"] = {
					["orientation"] = "HORIZONTAL",
					["textFormat"] = "PERCENT",
					["height"] = 16,
					["width"] = 200,
				},
				["bordercolor"] = {
					["b"] = 0.30588235294118,
					["g"] = 0.30588235294118,
					["r"] = 0.30588235294118,
				},
				["fontSize"] = 11,
				["valuecolor"] = {
					["a"] = 1,
					["b"] = 1,
					["g"] = 1,
					["r"] = 1,
				},
			},
			["movers"] = {
				["PetAB"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-50,-428",
				["ElvUF_RaidMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,51,120",
				["LeftChatMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,50,50",
				["GMMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,250,-50",
				["BossButton"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-117,-298",
				["LootFrameMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,249,-216",
				["ElvUF_RaidpetMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,50,827",
				["MicrobarMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,4,-52",
				["VehicleSeatMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,51,-87",
				["ElvUF_TargetTargetMover"] = "BOTTOM,ElvUIParent,BOTTOM,0,143",
				["ElvUF_Raid40Mover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,392,1073",
				["ElvAB_1"] = "BOTTOM,ElvUIParent,BOTTOM,0,50",
				["ElvAB_2"] = "BOTTOM,ElvUIParent,BOTTOM,0,90",
				["ElvAB_4"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-50,-394",
				["AltPowerBarMover"] = "TOP,ElvUIParent,TOP,0,-186",
				["ElvAB_3"] = "BOTTOM,ElvUIParent,BOTTOM,305,50",
				["ElvAB_5"] = "BOTTOM,ElvUIParent,BOTTOM,-305,50",
				["ElvUF_AssistMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,51,937",
				["ReputationBarMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-50,-228",
				["ObjectiveFrameMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-122,-393",
				["BNETMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,50,232",
				["ShiftAB"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,50,1150",
				["ElvUF_PlayerCastbarMover"] = "BOTTOM,ElvUIParent,BOTTOM,0,133",
				["RightChatMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-50,50",
				["ElvAB_6"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-488,330",
				["TooltipMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-50,50",
				["ElvUF_TankMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,50,995",
				["TotemBarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,463,50",
				["ElvUF_PetMover"] = "BOTTOM,ElvUIParent,BOTTOM,0,200",
				["ElvUF_PlayerMover"] = "BOTTOM,ElvUIParent,BOTTOM,-230,140",
				["ElvUF_PartyMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,184,773",
				["AlertFrameMover"] = "TOP,ElvUIParent,TOP,0,-50",
				["ElvUF_TargetMover"] = "BOTTOM,ElvUIParent,BOTTOM,230,140",
				["MinimapMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-50,-50",
			},
			["bags"] = {
				["itemLevelFontSize"] = 9,
				["countFontSize"] = 9,
			},
			["hideTutorial"] = true,
			["auras"] = {
				["font"] = "Expressway",
				["debuffs"] = {
					["countFontSize"] = 11,
					["durationFontSize"] = 11,
				},
				["buffs"] = {
					["countFontSize"] = 11,
					["maxWraps"] = 2,
					["durationFontSize"] = 11,
				},
			},
			["unitframe"] = {
				["statusbar"] = "ElvUI Blank",
				["fontOutline"] = "THICKOUTLINE",
				["smoothbars"] = true,
				["fontSize"] = 9,
				["font"] = "Expressway",
				["units"] = {
					["tank"] = {
						["enable"] = false,
					},
					["targettarget"] = {
						["infoPanel"] = {
							["enable"] = true,
						},
						["debuffs"] = {
							["enable"] = false,
						},
						["name"] = {
							["attachTextTo"] = "InfoPanel",
							["position"] = "TOP",
							["yOffset"] = -2,
						},
						["height"] = 50,
						["width"] = 122,
					},
					["target"] = {
						["debuffs"] = {
							["perrow"] = 7,
						},
						["power"] = {
							["attachTextTo"] = "InfoPanel",
							["hideonnpc"] = false,
							["text_format"] = "[powercolor][power:current-max]",
							["height"] = 15,
						},
						["infoPanel"] = {
							["enable"] = true,
						},
						["name"] = {
							["attachTextTo"] = "InfoPanel",
							["text_format"] = "[namecolor][name]",
						},
						["health"] = {
							["attachTextTo"] = "InfoPanel",
							["text_format"] = "[healthcolor][health:current-max]",
						},
						["height"] = 80,
						["buffs"] = {
							["perrow"] = 7,
						},
						["smartAuraPosition"] = "DEBUFFS_ON_BUFFS",
						["castbar"] = {
							["iconSize"] = 54,
							["iconAttached"] = false,
						},
					},
					["raid"] = {
						["roleIcon"] = {
							["position"] = "RIGHT",
						},
						["debuffs"] = {
							["enable"] = true,
							["sizeOverride"] = 27,
							["perrow"] = 4,
						},
						["rdebuffs"] = {
							["enable"] = false,
							["font"] = "Expressway",
						},
						["growthDirection"] = "UP_RIGHT",
						["health"] = {
							["yOffset"] = -6,
						},
						["groupsPerRowCol"] = 5,
						["height"] = 28,
						["name"] = {
							["position"] = "LEFT",
						},
						["visibility"] = "[nogroup] hide;show",
						["width"] = 140,
					},
					["player"] = {
						["infoPanel"] = {
							["enable"] = true,
						},
						["debuffs"] = {
							["perrow"] = 7,
						},
						["health"] = {
							["attachTextTo"] = "InfoPanel",
							["text_format"] = "[healthcolor][health:current-max]",
						},
						["power"] = {
							["attachTextTo"] = "InfoPanel",
							["text_format"] = "[powercolor][power:current-max]",
							["height"] = 15,
						},
						["height"] = 80,
						["name"] = {
							["attachTextTo"] = "InfoPanel",
							["text_format"] = "[namecolor][name]",
						},
						["classbar"] = {
							["height"] = 15,
							["autoHide"] = true,
						},
						["castbar"] = {
							["iconAttached"] = false,
							["iconSize"] = 54,
							["height"] = 35,
							["width"] = 478,
						},
					},
					["raid40"] = {
						["enable"] = false,
						["rdebuffs"] = {
							["font"] = "Expressway",
						},
					},
					["focus"] = {
						["infoPanel"] = {
							["height"] = 17,
							["enable"] = true,
						},
						["threatStyle"] = "NONE",
						["castbar"] = {
							["iconSize"] = 26,
							["width"] = 122,
						},
						["height"] = 56,
						["name"] = {
							["attachTextTo"] = "InfoPanel",
							["position"] = "LEFT",
						},
						["health"] = {
							["attachTextTo"] = "InfoPanel",
							["text_format"] = "[healthcolor][health:current]",
						},
						["width"] = 189,
					},
					["assist"] = {
						["enable"] = false,
					},
					["arena"] = {
						["spacing"] = 26,
						["castbar"] = {
							["width"] = 246,
						},
					},
					["party"] = {
						["horizontalSpacing"] = 3,
						["debuffs"] = {
							["numrows"] = 4,
							["anchorPoint"] = "BOTTOM",
							["perrow"] = 1,
						},
						["power"] = {
							["text_format"] = "",
							["height"] = 5,
						},
						["enable"] = false,
						["rdebuffs"] = {
							["font"] = "Expressway",
						},
						["growthDirection"] = "RIGHT_DOWN",
						["infoPanel"] = {
							["enable"] = true,
						},
						["width"] = 110,
						["health"] = {
							["attachTextTo"] = "InfoPanel",
							["orientation"] = "VERTICAL",
							["text_format"] = "[healthcolor][health:current]",
							["position"] = "RIGHT",
						},
						["name"] = {
							["attachTextTo"] = "InfoPanel",
							["text_format"] = "[namecolor][name:short]",
							["position"] = "LEFT",
						},
						["height"] = 59,
						["verticalSpacing"] = 0,
						["healPrediction"] = true,
						["roleIcon"] = {
							["position"] = "TOPRIGHT",
						},
					},
					["pet"] = {
						["infoPanel"] = {
							["enable"] = true,
							["height"] = 14,
						},
						["debuffs"] = {
							["enable"] = true,
						},
						["threatStyle"] = "NONE",
						["castbar"] = {
							["width"] = 122,
						},
						["height"] = 50,
						["portrait"] = {
							["camDistanceScale"] = 2,
						},
						["width"] = 122,
					},
				},
			},
			["datatexts"] = {
				["minimapPanels"] = false,
				["fontSize"] = 11,
				["panelTransparency"] = true,
				["goldFormat"] = "SHORT",
				["leftChatPanel"] = false,
				["font"] = "Expressway",
				["panels"] = {
					["BottomMiniPanel"] = "Time",
					["RightMiniPanel"] = "",
					["RightChatDataPanel"] = {
						["right"] = "",
						["left"] = "",
						["middle"] = "",
					},
					["LeftMiniPanel"] = "",
					["LeftChatDataPanel"] = {
						["right"] = "",
						["left"] = "",
						["middle"] = "",
					},
				},
				["rightChatPanel"] = false,
			},
			["actionbar"] = {
				["bar3"] = {
					["inheritGlobalFade"] = true,
					["buttonsize"] = 38,
					["buttonsPerRow"] = 3,
				},
				["fontSize"] = 9,
				["bar2"] = {
					["enabled"] = true,
					["inheritGlobalFade"] = true,
					["buttonsize"] = 38,
				},
				["bar1"] = {
					["heightMult"] = 2,
					["inheritGlobalFade"] = true,
					["buttonsize"] = 38,
				},
				["bar5"] = {
					["inheritGlobalFade"] = true,
					["buttonsize"] = 38,
					["buttonsPerRow"] = 3,
				},
				["globalFadeAlpha"] = 0.87,
				["stanceBar"] = {
					["inheritGlobalFade"] = true,
				},
				["bar6"] = {
					["buttonsize"] = 38,
				},
				["bar4"] = {
					["enabled"] = false,
					["backdrop"] = false,
					["buttonsize"] = 38,
				},
			},
			["layoutSet"] = "dpsMelee",
			["nameplates"] = {
				["filters"] = {
				},
			},
			["tooltip"] = {
				["textFontSize"] = 11,
				["font"] = "Expressway",
				["healthBar"] = {
					["font"] = "Expressway",
				},
				["headerFontSize"] = 11,
				["fontSize"] = 11,
				["smallTextFontSize"] = 11,
			},
			["chat"] = {
				["chatHistory"] = false,
				["fontSize"] = 11,
				["tabFont"] = "Expressway",
				["tabFontSize"] = 11,
				["fadeUndockedTabs"] = false,
				["editBoxPosition"] = "ABOVE_CHAT",
				["fadeTabsNoBackdrop"] = false,
				["font"] = "Expressway",
				["panelBackdrop"] = "HIDEBOTH",
			},
		},
		["Mavis - 灰烬使者"] = {
			["databars"] = {
				["experience"] = {
					["width"] = 309,
					["height"] = 5,
					["textSize"] = 9,
					["orientation"] = "HORIZONTAL",
				},
			},
			["currentTutorial"] = 13,
			["general"] = {
				["decimalLength"] = 0,
				["backdropfadecolor"] = {
					["a"] = 0.842945337295532,
					["r"] = 0.0196078431372549,
					["g"] = 0.0196078431372549,
					["b"] = 0.0196078431372549,
				},
				["valuecolor"] = {
					["a"] = 1,
				},
				["stickyFrames"] = false,
				["topPanel"] = false,
				["fontSize"] = 17,
				["autoRepair"] = "PLAYER",
				["minimap"] = {
					["size"] = 152,
				},
				["bottomPanel"] = false,
				["smoothingAmount"] = 0.36,
				["backdropcolor"] = {
					["a"] = 1,
					["r"] = 0.0392156862745098,
					["g"] = 0.0392156862745098,
					["b"] = 0.0392156862745098,
				},
				["itemLevel"] = {
					["itemLevelFont"] = "默认",
					["itemLevelFontSize"] = 19,
				},
				["bordercolor"] = {
					["a"] = 1,
					["r"] = 0,
					["g"] = 0,
					["b"] = 0,
				},
			},
			["movers"] = {
				["ElvUF_PlayerCastbarMover"] = "BOTTOM,ElvUIParent,BOTTOM,-2,206",
				["ElvUF_RaidMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,0,803",
				["LeftChatMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,0,0",
				["GMMover"] = "TOP,ElvUIParent,TOP,270,-3",
				["BuffsMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-3,-3",
				["BagsMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,0,200",
				["QuestWatchFrameMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-105,-163",
				["ElvUF_RaidpetMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,3,738",
				["DurabilityFrameMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,0,-307",
				["ElvUF_PetCastbarMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,0,-393",
				["ExperienceBarMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,0,1",
				["ElvUIBankMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-323,153",
				["ElvUF_Raid40Mover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,0,568",
				["ElvAB_1"] = "BOTTOM,ElvUIParent,BOTTOM,-117,2",
				["ElvAB_2"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-310,37",
				["ElvAB_4"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-310,2",
				["TaxiButtonMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,503,100",
				["ElvAB_3"] = "BOTTOM,ElvUIParent,BOTTOM,-117,37",
				["ElvAB_5"] = "BOTTOM,ElvUIParent,BOTTOM,-53,203",
				["MicrobarMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,0,225",
				["QuestTimerFrameMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,0,0",
				["RightChatMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,0,0",
				["PetAB"] = "BOTTOM,ElvUIParent,BOTTOM,0,73",
				["BNETMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,0,-82",
				["ElvNP_PlayerMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,0,-416",
				["ElvUF_PlayerMover"] = "BOTTOM,ElvUIParent,BOTTOM,-232,73",
				["ShiftAB"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,738,104",
				["ElvUF_TargetCastbarMover"] = "BOTTOM,ElvUIParent,BOTTOM,232,100",
				["TooltipMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,0,181",
				["ElvUIBagMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,0,153",
				["ElvUF_TargetTargetMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-431,101",
				["ElvUF_PetMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,503,97",
				["ElvUF_TargetMover"] = "BOTTOM,ElvUIParent,BOTTOM,232,73",
				["ElvUF_PartyMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,0,248",
				["AlertFrameMover"] = "BOTTOM,ElvUIParent,BOTTOM,12,209",
				["DebuffsMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-3,-99",
				["MinimapMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,0,21",
			},
			["bags"] = {
				["itemLevelFont"] = "PT Sans Narrow",
				["currencyFormat"] = "ICON_TEXT",
				["countFontSize"] = 17,
				["split"] = {
					["bag10"] = true,
					["bank"] = true,
					["bag8"] = true,
					["bag5"] = true,
					["bag3"] = true,
					["bag4"] = true,
					["bagSpacing"] = 0,
					["player"] = true,
					["bag1"] = true,
					["bag7"] = true,
					["bag2"] = true,
					["bag9"] = true,
					["bag11"] = true,
					["bag6"] = true,
				},
				["itemLevelFontSize"] = 17,
				["countFont"] = "PT Sans Narrow",
				["vendorGrays"] = {
					["enable"] = true,
				},
				["bagBar"] = {
					["growthDirection"] = "HORIZONTAL",
					["spacing"] = 1,
					["sortDirection"] = "DESCENDING",
					["mouseover"] = true,
					["backdropSpacing"] = 0,
					["size"] = 24,
				},
			},
			["hideTutorial"] = true,
			["auras"] = {
				["debuffs"] = {
					["countFontSize"] = 17,
					["durationFontSize"] = 17,
				},
				["font"] = "PT Sans Narrow",
				["buffs"] = {
					["countFontSize"] = 17,
					["durationFontSize"] = 17,
				},
			},
			["chat"] = {
				["shortChannels"] = false,
				["separateSizes"] = true,
				["panelHeightRight"] = 175,
				["tapFontSize"] = 17,
				["panelWidth"] = 502,
				["fontSize"] = 17,
				["tabFontSize"] = 13,
				["fadeUndockedTabs"] = false,
				["panelColorConverted"] = true,
				["panelHeight"] = 200,
				["lockPositions"] = false,
				["editBoxPosition"] = "ABOVE_CHAT",
				["panelWidthRight"] = 309,
				["panelColor"] = {
					["a"] = 0.158559024333954,
					["r"] = 0,
					["g"] = 0,
					["b"] = 0,
				},
				["fadeTabsNoBackdrop"] = false,
			},
			["unitframe"] = {
				["fontSize"] = 18,
				["statusbar"] = "Solid",
				["units"] = {
					["pet"] = {
						["castbar"] = {
							["enable"] = false,
						},
						["power"] = {
							["height"] = 4,
						},
						["width"] = 89,
						["health"] = {
							["position"] = "LEFT",
							["bgUseBarTexture"] = false,
						},
						["height"] = 10,
						["name"] = {
							["text_format"] = "",
						},
					},
					["player"] = {
						["debuffs"] = {
							["countFontSize"] = 4,
							["sizeOverride"] = 23,
							["enable"] = false,
							["yOffset"] = 22,
							["anchorPoint"] = "TOPRIGHT",
							["durationPosition"] = "BOTTOM",
							["countFont"] = "伤害数字",
							["attachTo"] = "BUFFS",
							["sortMethod"] = "PLAYER",
						},
						["portrait"] = {
							["generalOptionsGroup"] = true,
						},
						["fader"] = {
							["hover"] = false,
							["combat"] = false,
							["power"] = false,
							["enable"] = true,
							["health"] = false,
							["playertarget"] = false,
							["casting"] = false,
						},
						["CombatIcon"] = {
							["size"] = 17,
						},
						["aurabar"] = {
							["enable"] = false,
						},
						["RestIcon"] = {
							["size"] = 17,
						},
						["castbar"] = {
							["format"] = "CURRENT",
							["icon"] = false,
							["spark"] = false,
							["tickWidth"] = 8,
							["width"] = 293,
							["iconAttached"] = false,
							["height"] = 25,
							["latency"] = false,
						},
						["power"] = {
							["xOffset"] = 2,
							["text_format"] = "",
							["height"] = 8,
						},
						["width"] = 195,
						["health"] = {
							["position"] = "TOPRIGHT",
							["xOffset"] = 0,
							["bgUseBarTexture"] = true,
							["text_format"] = "",
							["yOffset"] = 20,
						},
						["name"] = {
							["xOffset"] = -63,
							["yOffset"] = 15,
						},
						["height"] = 25,
						["orientation"] = "RIGHT",
						["buffs"] = {
							["countFontSize"] = 6,
							["sizeOverride"] = 23,
							["yOffset"] = -17,
							["anchorPoint"] = "BOTTOMLEFT",
							["durationPosition"] = "BOTTOM",
							["countFont"] = "伤害数字",
							["countFontOutline"] = "NONE",
							["attachTo"] = "FRAME",
							["sortMethod"] = "PLAYER",
						},
						["smartAuraPosition"] = "FLUID_DEBUFFS_ON_BUFFS",
					},
					["raid40"] = {
						["rdebuffs"] = {
							["font"] = "PT Sans Narrow",
						},
					},
					["target"] = {
						["debuffs"] = {
							["countFontSize"] = 4,
							["sizeOverride"] = 20,
							["anchorPoint"] = "RIGHT",
							["priority"] = "CastByPlayers",
							["durationPosition"] = "BOTTOM",
							["countFont"] = "伤害数字",
							["attachTo"] = "FRAME",
							["sortMethod"] = "PLAYER",
						},
						["colorOverride"] = "FORCE_ON",
						["health"] = {
							["bgUseBarTexture"] = true,
							["xOffset"] = 0,
							["text_format"] = "[healthcolor][health:current]",
							["yOffset"] = 20,
						},
						["aurabar"] = {
							["enable"] = false,
						},
						["castbar"] = {
							["width"] = 195,
							["height"] = 15,
						},
						["width"] = 195,
						["power"] = {
							["text_format"] = "",
							["height"] = 7,
						},
						["smartAuraPosition"] = "FLUID_BUFFS_ON_DEBUFFS",
						["name"] = {
							["xOffset"] = -48,
							["yOffset"] = 20,
						},
						["height"] = 25,
						["buffs"] = {
							["countFontSize"] = 6,
							["sizeOverride"] = 24,
							["yOffset"] = -133,
							["anchorPoint"] = "RIGHT",
							["priority"] = "CastByPlayers",
							["durationPosition"] = "BOTTOM",
							["countFont"] = "伤害数字",
							["countFontOutline"] = "NONE",
							["attachTo"] = "DEBUFFS",
							["sortMethod"] = "PLAYER",
							["perrow"] = 10,
						},
						["fader"] = {
							["enable"] = false,
						},
					},
					["raid"] = {
						["rdebuffs"] = {
							["font"] = "PT Sans Narrow",
						},
					},
					["party"] = {
						["debuffs"] = {
							["enable"] = false,
						},
						["showPlayer"] = false,
						["name"] = {
							["yOffset"] = 16,
						},
						["height"] = 20,
						["buffs"] = {
							["priority"] = "Blacklist,CCDebuffs,PlayerBuffs,RaidBuffsElvUI,RaidDebuffs,TurtleBuffs,Whitelist",
						},
						["rdebuffs"] = {
							["font"] = "PT Sans Narrow",
						},
						["colorOverride"] = "FORCE_ON",
						["buffIndicator"] = {
							["enable"] = false,
						},
						["portrait"] = {
							["enable"] = true,
							["camDistanceScale"] = 1.48,
						},
						["power"] = {
							["text_format"] = "",
						},
						["width"] = 149,
						["sortDir"] = "DESC",
						["health"] = {
							["xOffset"] = 10,
							["text_format"] = "",
						},
						["petsGroup"] = {
							["anchorPoint"] = "BOTTOMLEFT",
							["name"] = {
								["text_format"] = "",
							},
							["enable"] = true,
							["height"] = 10,
							["width"] = 48,
						},
						["verticalSpacing"] = 18,
					},
					["targettarget"] = {
						["debuffs"] = {
							["enable"] = false,
						},
						["colorOverride"] = "FORCE_ON",
						["power"] = {
							["enable"] = false,
						},
						["name"] = {
							["xOffset"] = 3,
							["text_format"] = "[namecolor][name:short]",
							["yOffset"] = 16,
						},
						["width"] = 73,
						["fader"] = {
							["enable"] = false,
						},
						["height"] = 16,
						["buffs"] = {
							["yOffset"] = -356,
						},
					},
				},
				["font"] = "PT Sans Narrow",
				["colors"] = {
					["customcastbarbackdrop"] = true,
					["castColor"] = {
						["b"] = 0,
						["g"] = 0.980392156862745,
						["r"] = 1,
					},
					["health"] = {
						["r"] = 0,
						["g"] = 1,
						["b"] = 0.274509803921569,
					},
					["castbar_backdrop"] = {
						["b"] = 0,
						["g"] = 0,
						["r"] = 0,
					},
				},
				["fontOutline"] = "OUTLINE",
				["cooldown"] = {
					["fonts"] = {
						["enable"] = true,
						["fontSize"] = 19,
						["fontOutline"] = "MONOCHROMEOUTLINE",
					},
				},
			},
			["datatexts"] = {
				["minimapPanels"] = false,
				["fontSize"] = 13,
				["panelTransparency"] = true,
				["time24"] = false,
				["panels"] = {
					["RightChatDataPanel"] = {
						["right"] = "System",
						["left"] = "Time",
						["middle"] = "Coords",
					},
					["LeftChatDataPanel"] = {
						["right"] = "Time",
						["left"] = "Coords",
						["middle"] = "System",
					},
					["BottomRightMiniPanel"] = "System",
					["TopMiniPanel"] = "Coords",
					["BottomLeftMiniPanel"] = "Time",
				},
				["leftChatPanel"] = false,
				["panelBackdrop"] = false,
				["font"] = "默认",
			},
			["actionbar"] = {
				["bar3"] = {
					["buttons"] = 12,
					["buttonsPerRow"] = 12,
					["buttonsize"] = 34,
				},
				["font"] = "PT Sans Narrow",
				["hotkeyTextXOffset"] = 2,
				["hotkeyTextYOffset"] = 2,
				["barPet"] = {
					["point"] = "TOPLEFT",
					["backdrop"] = false,
					["widthMult"] = 5,
					["buttonsPerRow"] = 10,
					["buttonsize"] = 25,
				},
				["bar1"] = {
					["buttonsize"] = 34,
				},
				["microbar"] = {
					["enabled"] = true,
					["buttonSize"] = 16,
					["mouseover"] = true,
				},
				["bar2"] = {
					["enabled"] = true,
					["buttonsize"] = 34,
				},
				["bar5"] = {
					["enabled"] = false,
					["buttonsize"] = 34,
				},
				["lockActionBars"] = false,
				["bar6"] = {
					["buttonsize"] = 34,
				},
				["bar4"] = {
					["backdrop"] = false,
					["point"] = "BOTTOMLEFT",
					["buttonsPerRow"] = 12,
					["buttonsize"] = 34,
				},
			},
			["nameplates"] = {
				["units"] = {
					["ENEMY_NPC"] = {
						["enable"] = false,
					},
					["FRIENDLY_NPC"] = {
						["enable"] = false,
					},
					["PLAYER"] = {
						["visibility"] = {
							["showInCombat"] = false,
						},
					},
					["ENEMY_PLAYER"] = {
						["enable"] = false,
					},
					["FRIENDLY_PLAYER"] = {
						["enable"] = false,
					},
				},
				["visibility"] = {
					["showAll"] = false,
				},
			},
			["v11NamePlateReset"] = true,
			["tooltip"] = {
				["fontSize"] = 17,
				["headerFontSize"] = 17,
				["healthBar"] = {
					["font"] = "PT Sans Narrow",
				},
				["textFontSize"] = 17,
				["smallTextFontSize"] = 17,
			},
		},
	},
}
ElvPrivateDB = {
	["profileKeys"] = {
		["Mavis - 灰烬使者"] = "Mavis - 灰烬使者",
	},
	["profiles"] = {
		["Mavis - 灰烬使者"] = {
			["general"] = {
				["normTex"] = "Solid",
				["loot"] = false,
				["glossTex"] = "Solid",
			},
			["bags"] = {
				["bagBar"] = true,
			},
			["install_complete"] = "1.07",
		},
	},
}
