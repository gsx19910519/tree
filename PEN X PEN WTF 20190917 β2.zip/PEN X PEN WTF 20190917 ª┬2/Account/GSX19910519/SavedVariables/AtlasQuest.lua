
AtlasQuest_Options = {
	["Version"] = "4.11.51",
	["Mavis"] = {
		["ShownSide"] = "left",
		["AtlasAutoShow"] = 2,
		["NoQuerySpam"] = "yes",
	},
}
