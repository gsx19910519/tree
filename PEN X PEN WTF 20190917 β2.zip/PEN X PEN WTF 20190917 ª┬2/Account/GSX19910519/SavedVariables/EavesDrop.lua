
EavesDropDB = {
	["profileKeys"] = {
		["Mavis - 灰烬使者"] = "Mavis - 灰烬使者",
	},
	["profiles"] = {
		["Mavis - 灰烬使者"] = {
			["y"] = 12.8001378278022,
			["x"] = -681.955793296194,
		},
	},
}
