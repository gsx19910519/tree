
alaTalentEmuSV = {
	["inspectButtonKey"] = "ALT",
	["style"] = 1,
	["inspectButtonOnUnitFrame"] = false,
}
